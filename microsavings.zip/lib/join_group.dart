import 'package:flutter/material.dart';
import 'create_group.dart'; // Import the CreateGroupScreen

class JoinGroupScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: LayoutBuilder(
          builder: (context, constraints) {
            double width = constraints.maxWidth;
            double height = constraints.maxHeight;

            return Column(
              children: [
                // Header section with logo and background color
                Container(
                  padding: EdgeInsets.all(width * 0.05),
                  decoration: BoxDecoration(
                    color: Color(0xff2A356D),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(20.0),
                      bottomRight: Radius.circular(20.0),
                    ),
                  ),
                  width: double.infinity,
                  child: Column(
                    children: [
                      Image.asset(
                        'assets/images/title.png',
                        height: height * 0.25, // Responsive height
                      ),
                      SizedBox(height: height * 0.02),
                    ],
                  ),
                ),

                Expanded(
                  child: Padding(
                    padding: EdgeInsets.all(width * 0.05),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        SizedBox(height: height * 0.04),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            'Join a group',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: width * 0.05, // Responsive font size
                            ),
                          ),
                        ),

                        SizedBox(height: height * 0.02),
                        // Group Code TextField
                        buildTextFieldWithLabel('Group Code', width),
                        SizedBox(height: height * 0.1),
                        // Join button
                        ElevatedButton(
                          onPressed: () {
                            // Add join group logic here
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Color(0xFF2A3A75),
                            padding: EdgeInsets.symmetric(
                              vertical: height * 0.02,
                              horizontal: width * 0.1,
                            ),
                            minimumSize: Size(double.infinity, height * 0.07),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0),
                            ),
                          ),
                          child: Text(
                            'Join',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: width * 0.045, // Responsive font size
                            ),
                          ),
                        ),
                        SizedBox(height: height * 0.02),
                        Text(
                          'OR',
                          style: TextStyle(
                            fontSize: width * 0.04,
                            fontWeight: FontWeight.bold,
                            color: Colors.grey,
                          ),
                        ),
                        SizedBox(height: height * 0.02),
                        Container(
                          decoration: BoxDecoration(
                            color: Color(0xfff2f2f2),
                            borderRadius: BorderRadius.circular(12.0),
                          ),
                          child: TextButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => CreateGroupScreen()),
                              );
                            },
                            child: Text(
                              'CREATE A GROUP',
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: width * 0.045, // Responsive font size
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  // A helper function to create a TextField with a label above it
  Widget buildTextFieldWithLabel(String label, double width) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: width * 0.02), // Space between label and TextField
        TextField(
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.0),
            ),
            hintText: 'Enter your $label',
            hintStyle: TextStyle(color: Colors.grey[400]),
          ),
        ),
      ],
    );
  }
}
