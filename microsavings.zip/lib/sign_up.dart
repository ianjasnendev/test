import 'package:flutter/material.dart';
import 'create_group.dart';
import 'main.dart'; // Import the CreateGroupScreen

void main() {
  runApp(SignUpApp());
}

class SignUpApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SignUpScreen(),
    );
  }
}

class SignUpScreen extends StatefulWidget {
  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  bool _passwordVisible = false;
  bool _confirmPasswordVisible = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon:
              Image.asset('assets/icons/arrow_back.png', height: 30, width: 30),
          onPressed: () {
            Navigator.popUntil(context,
                (route) => route.isFirst); // Navigate to the root screen
          },
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final double width = constraints.maxWidth;
          final double height = constraints.maxHeight;
          final double padding = width * 0.05;
          final double fontSize = width * 0.05;
          final double buttonHeight = height * 0.07;

          return Padding(
            padding: EdgeInsets.all(padding),
            child: Form(
              key: _formKey,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      'Sign up',
                      style: TextStyle(
                        fontSize: fontSize * 1.4, // Responsive font size
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: height * 0.03),
                    _buildLabel('First Name', fontSize),
                    SizedBox(height: height * 0.01),
                    _buildTextField(
                      label: 'Firstname',
                      hint: 'Enter your first name',
                      controller: _firstNameController,
                      width: width,
                      fontSize: fontSize,
                    ),
                    SizedBox(height: height * 0.02),
                    _buildLabel('Last Name', fontSize),
                    SizedBox(height: height * 0.01),
                    _buildTextField(
                      label: 'Lastname',
                      hint: 'Enter your last name',
                      controller: _lastNameController,
                      width: width,
                      fontSize: fontSize,
                    ),
                    SizedBox(height: height * 0.02),
                    _buildLabel('Email Address', fontSize),
                    SizedBox(height: height * 0.01),
                    _buildTextField(
                      label: 'Email',
                      hint: 'Enter your email',
                      controller: _emailController,
                      keyboardType: TextInputType.emailAddress,
                      width: width,
                      fontSize: fontSize,
                    ),
                    SizedBox(height: height * 0.02),
                    _buildLabel('Password', fontSize),
                    SizedBox(height: height * 0.01),
                    _buildTextField(
                      label: 'Create a password',
                      hint: 'Must be 8 characters',
                      controller: _passwordController,
                      obscureText: !_passwordVisible,
                      suffixIcon: IconButton(
                        icon: Icon(
                          _passwordVisible
                              ? Icons.visibility
                              : Icons.visibility_off,
                        ),
                        onPressed: () {
                          setState(() {
                            _passwordVisible = !_passwordVisible;
                          });
                        },
                      ),
                      width: width,
                      fontSize: fontSize,
                    ),
                    SizedBox(height: height * 0.02),
                    _buildLabel('Confirm Password', fontSize),
                    SizedBox(height: height * 0.01),
                    _buildTextField(
                      label: 'Confirm password',
                      hint: 'Re-enter your password',
                      controller: _confirmPasswordController,
                      obscureText: !_confirmPasswordVisible,
                      suffixIcon: IconButton(
                        icon: Icon(
                          _confirmPasswordVisible
                              ? Icons.visibility
                              : Icons.visibility_off,
                        ),
                        onPressed: () {
                          setState(() {
                            _confirmPasswordVisible = !_confirmPasswordVisible;
                          });
                        },
                      ),
                      width: width,
                      fontSize: fontSize,
                    ),
                    SizedBox(height: height * 0.03),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => CreateGroupScreen()),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xff253672),
                        padding: EdgeInsets.symmetric(
                          vertical: height * 0.015,
                          horizontal: width * 0.05,
                        ),
                        minimumSize: Size(double.infinity, buttonHeight),
                        textStyle: TextStyle(fontSize: fontSize),
                        foregroundColor: Colors.white,
                      ),
                      child: Text('Sign up'),
                    ),
                    SizedBox(height: height * 0.02),
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => MicroSavingsApp()),
                        );
                      },
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: 'Already have an account? ',
                              style: TextStyle(
                                  color: Colors.black, fontSize: fontSize),
                            ),
                            TextSpan(
                              text: 'Log in',
                              style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: fontSize,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // Method to build TextFormField with consistent border styling
  Widget _buildTextField({
    required String label,
    required String hint,
    required TextEditingController controller,
    bool obscureText = false,
    TextInputType? keyboardType,
    Widget? suffixIcon,
    required double width,
    required double fontSize,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: obscureText,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        labelStyle:
            TextStyle(fontSize: fontSize * 0.8), // Responsive label font size
        hintStyle:
            TextStyle(fontSize: fontSize * 0.7), // Responsive hint font size
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12.0),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.grey),
          borderRadius: BorderRadius.circular(12.0),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.blue),
          borderRadius: BorderRadius.circular(12.0),
        ),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        suffixIcon: suffixIcon,
      ),
    );
  }

  // Method to build label with responsive font size
  Widget _buildLabel(String text, double fontSize) {
    return Text(
      text,
      style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: fontSize, // Responsive font size
      ),
    );
  }
}
