import 'package:flutter/material.dart';
import 'qr_code_scanner.dart';
import 'home.dart';

void main() {
  runApp(Historypage());
}

class Historypage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.white,
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(height: 50),

            // Remaining Balance Section
            Center(
              // Wrap in Center to control the width in the middle of the screen
              child: Container(
                width: 340, // Adjust the width here
                height: 100, // set the height to 100
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Color(0xff2A356D),
                  borderRadius: BorderRadius.circular(25),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Remaining Balance",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "PHP 45,000",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 30),

            // History Section Title
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                "History",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),

            // History Section with Scrollable ListView
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16.0),
                children: [
                  // History Card 1
                  HistoryCard(
                    userName: 'USER 1',
                    imagePath: 'assets/images/luffy.jpg',
                    amount: 'PHP 50,000',
                    date: '10 Jan 2022',
                    transactionType: 'CASH OUT',
                  ),
                  SizedBox(height: 10),

                  // History Card 2
                  HistoryCard(
                    userName: 'YOU',
                    imagePath: 'assets/images/ace.jpg',
                    amount: 'PHP 5,000',
                    date: '10 Jan 2020',
                    transactionType: 'CASH IN',
                  ),
                  SizedBox(height: 10),

                  // History Card 3
                  HistoryCard(
                    userName: 'USER 2',
                    imagePath: 'assets/images/sabo.jpg',
                    amount: 'PHP 50,000',
                    date: '10 Jan 2021',
                    transactionType: 'CASH OUT',
                  ),
                  SizedBox(height: 10),

                  // History Card 4
                  HistoryCard(
                    userName: 'YOU',
                    imagePath: 'assets/images/ace.jpg',
                    amount: 'PHP 50,000',
                    date: '10 Jan 2020',
                    transactionType: 'CASH OUT',
                  ),
                ],
              ),
            ),
          ],
        ),

        // FloatingActionButton and BottomAppBar
        floatingActionButton: SizedBox(
          height: 56,
          width: 56,
          child: FloatingActionButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => QRViewExample()),
              );
            },
            child: Image.asset('assets/icons/logo.png', fit: BoxFit.cover),
            backgroundColor: Color(0xff2A356D),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(28),
            ),
          ),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,

        bottomNavigationBar: BottomAppBar(
          shape: CircularNotchedRectangle(),
          notchMargin: 8.0,
          color: Color(0xff2A356D),
          child: Container(
            height: 60,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Homepage()),
                    );
                  },
                  icon: Image.asset('assets/icons/home.png',
                      height: 30, width: 30),
                ),
                SizedBox(width: 20),
                IconButton(
                  onPressed: () {},
                  icon: Image.asset('assets/icons/history.png',
                      height: 30, width: 30),
                ),
                Spacer(),
                SizedBox(width: 20),
                IconButton(
                  onPressed: () {},
                  icon: Image.asset('assets/icons/payment.png',
                      height: 30, width: 30),
                ),
                SizedBox(width: 20),
                IconButton(
                  onPressed: () {},
                  icon: Image.asset('assets/icons/user.png',
                      height: 30, width: 30),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Reusable widget for history cards
class HistoryCard extends StatelessWidget {
  final String userName;
  final String imagePath;
  final String amount;
  final String date;
  final String transactionType;

  HistoryCard({
    required this.userName,
    required this.imagePath,
    required this.amount,
    required this.date,
    required this.transactionType,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 250, // Set a smaller width here for the history card
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 30,
            backgroundImage: AssetImage(imagePath),
          ),
          SizedBox(width: 20),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                userName,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(date, style: TextStyle(color: Colors.grey)),
            ],
          ),
          Spacer(),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                amount,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(transactionType, style: TextStyle(color: Colors.grey)),
            ],
          ),
        ],
      ),
    );
  }
}
