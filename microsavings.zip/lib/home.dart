import 'package:flutter/material.dart';
import 'qr_code_scanner.dart';
import 'create_goal.dart';
import 'history.dart';

void main() {
  runApp(Homepage());
}

class Homepage extends StatefulWidget {
  @override
  _HomepageState createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  // Declare ScrollController
  final ScrollController _scrollController = ScrollController();
  String _goalAmount = "PHP 100,000"; // Default goal amount

  @override
  void dispose() {
    // Dispose of the controller when no longer needed to free resources
    _scrollController.dispose();
    super.dispose();
  }

  void _updateGoalAmount(String newGoal) {
    setState(() {
      _goalAmount = newGoal;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Your Share Section
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Color(0xff2A356D),
                  borderRadius: BorderRadius.circular(25),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Your Share",
                      style: TextStyle(color: Colors.white, fontSize: 18),
                    ),
                    SizedBox(height: 15),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "PHP 10,000",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        CircleAvatar(
                          radius: 30,
                          backgroundImage: AssetImage(
                              'assets/images/ace.jpg'), // Add your image
                        ),
                      ],
                    ),
                    SizedBox(height: 15),
                    Text(
                      "SPACE",
                      style: TextStyle(color: Color(0xff2A356D)),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 20),

              // Target Goal Section
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Color(0xff2A356D),
                  borderRadius: BorderRadius.circular(25),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Target Goal",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                          ),
                        ),
                        Text(
                          _goalAmount, // Display the updated goal amount
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 10),
                    Stack(
                      children: [
                        ClipRRect(
                          borderRadius:
                              BorderRadius.circular(20), // Rounded corners
                          child: Container(
                            height:
                                20, // Adjust this value to make the progress indicator thicker
                            child: LinearProgressIndicator(
                              value:
                                  0.45, // Represents PHP 45,000 / PHP 100,000
                              backgroundColor: Colors.grey[300],
                              color: Colors.white,
                            ),
                          ),
                        ),
                        Positioned(
                          left: 0,
                          right: 0,
                          top: 0,
                          bottom: 0,
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Padding(
                              padding: EdgeInsets.symmetric(horizontal: 8.0),
                              child: Text(
                                "PHP 45,000",
                                style: TextStyle(
                                  color: Color(0xff7c7c7c),
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 10),
                  ],
                ),
              ),

              SizedBox(height: 20),

              // Create New Goal Button
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Create a New Goal",
                      style: TextStyle(color: Color(0xff2f2f30), fontSize: 16),
                    ),
                    IconButton(
                      onPressed: () async {
                        final newGoal = await Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => NewGoal()),
                        );
                        if (newGoal != null) {
                          _updateGoalAmount(newGoal);
                        }
                      },
                      icon: Image.asset('assets/icons/plus.png',
                          height: 30, width: 30),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 20),

              // Other Sharers Section
              Text(
                "Other Sharers",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),

              // Horizontal Scroll for Sharers with ScrollController
              Scrollbar(
                thumbVisibility: false,
                controller: _scrollController, // Attach ScrollController here
                child: SingleChildScrollView(
                  controller:
                      _scrollController, // Attach ScrollController here too
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _buildSharerCard('assets/images/luffy.jpg', 'PHP 10,000',
                          'User 1 Share'),
                      SizedBox(width: 10),
                      _buildSharerCard('assets/images/sabo.jpg', 'PHP 10,000',
                          'User 2 Share'),
                      SizedBox(width: 10),
                      _buildSharerCard('assets/images/zoro.jpg', 'PHP 5,000',
                          'User 3 Share'),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),

        // FloatingActionButton and BottomAppBar
        floatingActionButton: SizedBox(
          height: 56, // Control the size of the FAB
          width: 56,
          child: FloatingActionButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => QRViewExample()),
              );
            },
            child: Image.asset('assets/icons/logo.png', fit: BoxFit.cover),
            backgroundColor: Color(0xff2A356D),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(28),
            ),
          ),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,

        bottomNavigationBar: BottomAppBar(
          shape: CircularNotchedRectangle(),
          notchMargin: 8.0,
          color: Color(0xff2A356D),
          child: Container(
            height: 60,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  onPressed: () {},
                  icon: Image.asset('assets/icons/home.png',
                      height: 30, width: 30),
                ),
                SizedBox(width: 20),
                IconButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Historypage()),
                    );
                  },
                  icon: Image.asset('assets/icons/history.png',
                      height: 30, width: 30),
                ),
                Spacer(),
                SizedBox(width: 20),
                IconButton(
                  onPressed: () {},
                  icon: Image.asset('assets/icons/payment.png',
                      height: 30, width: 30),
                ),
                SizedBox(width: 20),
                IconButton(
                  onPressed: () {},
                  icon: Image.asset('assets/icons/user.png',
                      height: 30, width: 30),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Method to build the Sharer Card
  Widget _buildSharerCard(String imagePath, String amount, String sharerName) {
    return Container(
      width: 150, // Set width for each sharer card
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Color(0xffe0e7f1), // Sharer card background color
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        children: [
          CircleAvatar(
            radius: 30,
            backgroundImage: AssetImage(imagePath), // Sharer image
          ),
          SizedBox(height: 40),
          Text(
            amount,
            style: TextStyle(
              color: Color(0xff2f2f30),
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            sharerName,
            style: TextStyle(
              color: Color(0xff7c7c7c),
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}
