import 'package:flutter/material.dart';
import 'sign_up.dart';
import 'home.dart';

void main() {
  runApp(MicroSavingsApp());
}

class MicroSavingsApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SignInScreen(),
    );
  }
}

class SignInScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: LayoutBuilder(
        builder: (context, constraints) {
          // Get screen width and height
          double width = constraints.maxWidth;
          double height = constraints.maxHeight;

          return Padding(
            padding: EdgeInsets.all(
                width * 0.05), // Adjust padding based on screen width
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Logo and app name
                Center(
                  child: Column(
                    children: [
                      Image.asset(
                        'assets/images/title.png',
                        width: width * 0.8, // Responsive width
                        height: height * 0.25, // Responsive height
                      ),
                      SizedBox(height: height * 0.02), // Responsive spacing
                    ],
                  ),
                ),
                SizedBox(height: height * 0.02),
                // Sign In / Sign Up toggle
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton(
                      onPressed: () {},
                      child: Text(
                        'Sign In',
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Text(
                      '/',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => SignUpScreen()),
                        );
                      },
                      child: Text(
                        'Sign Up',
                        style: TextStyle(
                          color: Colors.grey,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: height * 0.02),
                // Email TextField
                Text(
                  'Email Address',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: width * 0.04, // Responsive font size
                  ),
                ),
                SizedBox(height: height * 0.01),
                TextField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                    hintText: 'Your email',
                  ),
                ),
                SizedBox(height: height * 0.02),

                // Password Label and TextField
                Text(
                  'Password',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: width * 0.04,
                  ),
                ),
                SizedBox(height: height * 0.01),
                TextField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                    hintText: 'Password',
                    suffixIcon: Icon(Icons.visibility_off),
                  ),
                  obscureText: true,
                ),
                SizedBox(height: height * 0.02),

                // Forgot Password
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () {},
                    child: Text('Forgot password?'),
                  ),
                ),
                SizedBox(height: height * 0.02),
                // Sign in button
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Homepage()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xff253672),
                    padding: EdgeInsets.symmetric(
                        vertical: height * 0.02, horizontal: width * 0.05),
                    minimumSize: Size(double.infinity, height * 0.07),
                    textStyle: TextStyle(fontSize: width * 0.045),
                    foregroundColor: Colors.white,
                  ),
                  child: Text('Sign in'),
                ),
                SizedBox(height: height * 0.02),
                // Other sign-in options
                Center(
                  child: Text('Other sign in options'),
                ),
                SizedBox(height: height * 0.02),
                // Sign in with Facebook, Google, Apple
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      onPressed: () {},
                      icon: Image.asset('assets/icons/facebook.png',
                          height: height * 0.04, width: height * 0.04),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: Image.asset('assets/icons/google.png',
                          height: height * 0.04, width: height * 0.04),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: Image.asset('assets/icons/apple.png',
                          height: height * 0.04, width: height * 0.04),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
