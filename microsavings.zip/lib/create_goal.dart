import 'package:flutter/material.dart';
import 'home.dart';
import 'package:intl/intl.dart';

void main() => runApp(NewGoal());

class NewGoal extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: AmountEntryScreen(),
    );
  }
}

class AmountEntryScreen extends StatefulWidget {
  @override
  _AmountEntryScreenState createState() => _AmountEntryScreenState();
}

class _AmountEntryScreenState extends State<AmountEntryScreen> {
  String _amount = "0"; // Initial amount is zero

  void _onKeyPress(String value) {
    setState(() {
      if (value == 'x') {
        // Clear the input
        _amount = "0";
      } else if (value == '<') {
        // Remove last digit
        _amount =
            _amount.length > 1 ? _amount.substring(0, _amount.length - 1) : "0";
      } else {
        // Append the number pressed
        if (_amount == "0") {
          _amount = value;
        } else {
          _amount += value;
        }
      }

      // Format the amount with thousands separators
      _amount = _formatNumber(_amount);
    });
  }

  // Method to format number with thousand separators
  String _formatNumber(String amount) {
    if (amount.isEmpty || amount == "0") return "0";

    final number = int.tryParse(amount.replaceAll(',', ''));
    if (number == null) return amount;

    final formatter = NumberFormat('#,###');
    return formatter.format(number);
  }

  @override
  Widget build(BuildContext context) {
    // Get screen size
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    final isSmallScreen = screenWidth < 400; // Define what qualifies as small

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon:
              Image.asset('assets/icons/arrow_back.png', width: 24, height: 24),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Homepage()),
            );
          },
        ),
      ),
      body: SingleChildScrollView(
        // Use SingleChildScrollView to avoid overflow on small screens
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: screenHeight * 0.02),
            // Container for label and display
            Container(
              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.05),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Label text
                  Text(
                    "Enter Amount",
                    style: TextStyle(
                      fontSize: isSmallScreen ? 14 : 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(height: screenHeight * 0.01),
                  // Display the amount entered
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(
                      horizontal: screenWidth * 0.1,
                      vertical: screenHeight * 0.02,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.3),
                          spreadRadius: 2,
                          blurRadius: 5,
                          offset: Offset(0, 3), // changes position of shadow
                        ),
                      ],
                    ),
                    child: Center(
                      child: Text(
                        _amount,
                        style: TextStyle(
                          fontSize: isSmallScreen ? 32 : 40,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: screenHeight * 0.02),

            // Numeric Keypad
            GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.1),
              childAspectRatio: isSmallScreen ? 1.0 : 1.2, // Adjusts key size
              children: [
                _buildKey("1"),
                _buildKey("2"),
                _buildKey("3"),
                _buildKey("4"),
                _buildKey("5"),
                _buildKey("6"),
                _buildKey("7"),
                _buildKey("8"),
                _buildKey("9"),
                _buildKey("x"), // Clear button
                _buildKey("0"),
                _buildKey("<"), // Backspace button
              ],
            ),
            SizedBox(height: screenHeight * 0.02),
            // Enter button
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Homepage()),
                );
              },
              child: Text(
                "Enter",
                style: TextStyle(
                  fontSize: isSmallScreen ? 16 : 20,
                  color: Colors.white,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF2A3A75),
                padding: EdgeInsets.symmetric(
                  horizontal: screenWidth * 0.2,
                  vertical: screenHeight * 0.02,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Build keypad buttons
  Widget _buildKey(String value) {
    return GestureDetector(
      onTap: () => _onKeyPress(value),
      child: Container(
        margin: EdgeInsets.all(10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.grey[200],
        ),
        child: Center(
          child: Text(
            value,
            style: TextStyle(
              fontSize: MediaQuery.of(context).size.width < 400 ? 24 : 30,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}
